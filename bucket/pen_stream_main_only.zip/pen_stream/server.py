print('DEBUG: Starting broadcast server script...')
import http.server
import socketserver
import os
import json

# --- CONFIGURATION ---
PORT = 8000
DIRECTORY = "/home/rahulraj/pen_stream"
# This file stores which story is currently "On Air"
STATUS_FILE = os.path.join(DIRECTORY, "bucket/news/queue/playout_status.json")

class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        print("DEBUG: %s - - [%s] %s" % (self.client_address[0], self.log_date_time_string(), format%args))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    # 1. Disable Caching (So OBS sees updates instantly)
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.send_header('Access-Control-Allow-Origin', '*') 
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    # 2. Handle CORS Preflight
    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    # 3. HANDLE THE SYNC SIGNAL (The Missing Piece)
    def do_POST(self):
        if self.path == '/sync':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            try:
                # Save the status sent by HTML
                data = json.loads(post_data)
                # Ensure directory exists
                os.makedirs(os.path.dirname(STATUS_FILE), exist_ok=True)
                with open(STATUS_FILE, 'w') as f:
                    json.dump(data, f)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b'{"status": "ok"}')
            except Exception as e:
                print(f"❌ Sync Error: {e}")
                self.send_response(500)
                self.end_headers()
        else:
            self.send_error(404)

    # 4. SIMPLE VIDEO PROXY (to avoid browser CORS / hotlinking issues)
    def do_GET(self):
        # If request is for the proxy endpoint, handle it; otherwise fall back to default file handler
        from urllib.parse import urlparse, parse_qs, unquote
        import requests

        if self.path.startswith('/proxy_video'):
            qs = parse_qs(urlparse(self.path).query)
            target = None
            if 'url' in qs:
                target = qs['url'][0]
            else:
                # try after ?url=... or /proxy_video?url=...
                parts = self.path.split('?')
                if len(parts) > 1:
                    q = parts[1]
                    try:
                        # crude parse
                        for p in q.split('&'):
                            if p.startswith('url='):
                                target = unquote(p.split('=',1)[1])
                    except Exception:
                        target = None

            if not target:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b'{"error":"missing url"}')
                return

            # Whitelist simple hosts to avoid open proxy abuse
            try:
                parsed = urlparse(target)
                hostname = parsed.hostname or ''
            except Exception:
                hostname = ''

            allowed_hosts = ['videos.pexels.com', 'images.pexels.com', 'player.vimeo.com', 'vimeo.com']
            if not any(hostname.endswith(h) for h in allowed_hosts):
                self.send_response(403)
                self.end_headers()
                self.wfile.write(b'{"error":"forbidden host"}')
                return

            try:
                # Stream the remote content
                with requests.get(target, stream=True, timeout=10) as r:
                    status = r.status_code
                    self.send_response(status)
                    # forward a couple of headers
                    ctype = r.headers.get('Content-Type')
                    clen = r.headers.get('Content-Length')
                    if ctype:
                        self.send_header('Content-Type', ctype)
                    self.send_header('Access-Control-Allow-Origin', '*')
                    # no-cache for live preview
                    self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
                    if clen:
                        try:
                            self.send_header('Content-Length', clen)
                        except Exception:
                            pass
                    self.end_headers()
                    for chunk in r.iter_content(chunk_size=64*1024):
                        if chunk:
                            self.wfile.write(chunk)
                return
            except Exception as e:
                print(f"Proxy error: {e}")
                self.send_response(502)
                self.end_headers()
                self.wfile.write(b'{"error":"bad gateway"}')

        # fallback to default handler for other GETs
        return super().do_GET()

print(f"📡 BROADCAST SERVER ACTIVE (Port {PORT})")
print(f"📂 Root: {DIRECTORY}")

# Allow immediate restart if it crashes
socketserver.TCPServer.allow_reuse_address = True

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer Stopped.")
        httpd.server_close()