import asyncio
import sys
import requests
import time
from langgraph.graph import StateGraph, END
from nodes import (
    BreakingState, TrendingState,
    check_wires_node, analyze_urgency_node,
    collect_and_cluster_node, safety_filter_node, editor_production_node,
    generate_ticker_node
)

# --- 0. FORCE UNBUFFERED OUTPUT (So you see logs instantly) ---
sys.stdout.reconfigure(line_buffering=True)

def check_gpu_status(port, name):
    """Pings the Ollama instance to ensure it is alive."""
    url = f"http://127.0.0.1:{port}/api/tags"
    try:
        print(f"   Testing {name} (Port {port})... ", end="", flush=True)
        response = requests.get(url, timeout=2)
        if response.status_code == 200:
            print("✅ ONLINE")
            return True
        else:
            print(f"❌ ERROR (Status {response.status_code})")
            return False
    except:
        print("❌ UNREACHABLE (Is 'ollama serve' running?)")
        return False

# --- GRAPH DEFINITIONS ---
# (Keeping your existing graph structure exactly as is)
workflow_break = StateGraph(BreakingState)
workflow_break.add_node("scan", check_wires_node)
workflow_break.add_node("analyze", analyze_urgency_node)
workflow_break.set_entry_point("scan")
workflow_break.add_edge("scan", "analyze")
workflow_break.add_edge("analyze", END)
app_break = workflow_break.compile()

workflow_trend = StateGraph(TrendingState)
workflow_trend.add_node("collect", collect_and_cluster_node)
workflow_trend.add_node("filter", safety_filter_node)
workflow_trend.add_node("editor", editor_production_node)
workflow_trend.set_entry_point("collect")
workflow_trend.add_edge("collect", "filter")
workflow_trend.add_edge("filter", "editor")
workflow_trend.add_edge("editor", END)
app_trend = workflow_trend.compile()

workflow_ticker = StateGraph(TrendingState)
workflow_ticker.add_node("gen_ticker", generate_ticker_node)
workflow_ticker.set_entry_point("gen_ticker")
workflow_ticker.add_edge("gen_ticker", END)
app_ticker = workflow_ticker.compile()

# --- RUNNERS ---

async def run_breaking_loop():
    print(">>> [GPU 0] Breaking Loop Started")
    while True:
        try:
            await app_break.ainvoke({"search_results": "", "is_urgent": False})
            await asyncio.sleep(300) 
        except Exception as e:
            print(f"[GPU 0 Error] {e}")
            await asyncio.sleep(60)

async def run_trending_loop():
    print(">>> [GPU 1] Trending Loop Started")
    while True:
        try:
            await app_trend.ainvoke({"raw_search_results": "", "candidates": [], "approved_stories": []})
            print(">>> Trending Cycle Complete. Sleeping 5m...")
            await asyncio.sleep(300) 
        except Exception as e:
            print(f"[GPU 1 Error] {e}")
            await asyncio.sleep(60)

async def run_ticker_loop():
    print(">>> [GPU 1] Ticker Loop Started")
    while True:
        try:
            await app_ticker.ainvoke({"raw_search": ""})
            print(">>> Ticker Cycle Complete. Sleeping 10m...")
            await asyncio.sleep(600)
        except Exception as e:
            print(f"[Ticker Error] {e}")
            await asyncio.sleep(60)

if __name__ == "__main__":
    print("\n=======================================")
    print("   DUAL GPU AI NEWS STATION STARTING   ")
    print("=======================================")
    
    # --- PRE-FLIGHT CHECK ---
    print("1. Checking GPU Engines:")
    gpu0_ok = check_gpu_status(11436, "GPU 0 (Breaking)")
    gpu1_ok = check_gpu_status(11435, "GPU 1 (Trending)")
    
    if not gpu0_ok or not gpu1_ok:
        print("\n[CRITICAL ERROR] One or more GPUs are offline.")
        print("Please check your other terminals and ensure 'ollama serve' is running.")
        if not gpu0_ok: print("-> Run: CUDA_VISIBLE_DEVICES=0 OLLAMA_HOST=127.0.0.1:11436 ollama serve")
        if not gpu1_ok: print("-> Run: CUDA_VISIBLE_DEVICES=1 OLLAMA_HOST=127.0.0.1:11435 ollama serve")
        sys.exit(1)
        
    print("2. System Status: ALL GREEN. Starting Loops...")
    print("---------------------------------------")

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    tasks = asyncio.gather(
        run_breaking_loop(), 
        run_trending_loop(),
        run_ticker_loop()
    )
    
    try:
        loop.run_until_complete(tasks)
    except KeyboardInterrupt:
        print("Shutting down...")