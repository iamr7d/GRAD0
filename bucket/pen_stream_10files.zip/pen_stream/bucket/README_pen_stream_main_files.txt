Pen Stream — Selected main files archive
Created: $(date -u +"%Y-%m-%d %H:%M:%SZ")

This archive contains the main project source files (9) plus this README (total 10 files).
Below are the absolute paths of each file included in the archive:

1) /home/rahulraj/pen_stream/server.py
2) /home/rahulraj/pen_stream/broadcast_screen.html
3) /home/rahulraj/pen_stream/admin_timeline.html
4) /home/rahulraj/pen_stream/stream/main_stream.py
5) /home/rahulraj/pen_stream/stream/graphics_engine.py
6) /home/rahulraj/pen_stream/overlays/broadcast_screen.html
7) /home/rahulraj/pen_stream/overlays/main_card.html
8) /home/rahulraj/pen_stream/overlays/server.py
9) /home/rahulraj/pen_stream/server_fastapi.py

README path inside archive:
10) /bucket/README_pen_stream_main_files.txt

Notes:
- I excluded large folders (venvs, ffmpeg, models, raw media) per your previous request.
- If you want a different selection of main files, tell me which to swap and I will recreate the zip.
